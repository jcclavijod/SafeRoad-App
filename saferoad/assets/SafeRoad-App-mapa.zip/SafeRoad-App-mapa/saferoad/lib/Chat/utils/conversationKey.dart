class ConversationKey {
  static const String collectionName = 'conversations';
  static const String members = 'members';
  static const String id = 'id';
  static const String creator = 'creator';
  static const String receiver = 'receiver';
}